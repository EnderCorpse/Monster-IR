export interface Env {
  AI: Ai;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405, headers: corsHeaders });
    }

    try {
      let data: Record<string, any> = {};
      let logContent = "No log files provided.";
      
      const contentType = request.headers.get("content-type") || "";
      
      if (contentType.includes("multipart/form-data")) {
        const formData = await request.formData();
        data = {
          incident_type: formData.get("incident_type"),
          severity: formData.get("severity"),
          start_time: formData.get("start_time"),
          end_time: formData.get("end_time"),
          affected_systems: formData.get("affected_systems"),
          detection_method: formData.get("detection_method"),
          actions_taken: formData.get("actions_taken")
        };
        
        const logFile = formData.get("log_file") as File;
        if (logFile) {
          logContent = await logFile.text();
        }
      } 
      else if (contentType.includes("application/json")) {
        data = await request.json();
        logContent = data.log_content || logContent;
      }

      const truncatedLogs = logContent.substring(0, 2000);

      const prompt = `You are an expert cybersecurity analyst. Generate a formal, objective Cyber Incident Report based on the following raw data and log evidence. 
      Format the output cleanly using Markdown with the following sections: Executive Summary, Incident Details, Impact Analysis, Actions Taken, Log Analysis Summary, and Recommendations for Remediation.

      RAW INCIDENT DATA:
      - Incident Type: ${data.incident_type || "Not specified"}
      - Severity Level: ${data.severity || "Not specified"}
      - Start Time: ${data.start_time || "Not specified"}
      - End Time: ${data.end_time || "Ongoing"}
      - Affected Systems/Assets: ${data.affected_systems || "Not specified"}
      - Initial Detection Method: ${data.detection_method || "Not specified"}
      - Actions Taken: ${data.actions_taken || "Not specified"}
      
      LOG EVIDENCE SNIPPET:
      ${truncatedLogs}
      `;

      const response = await env.AI.run('@cf/meta/llama-4-scout-17b-16e-instruct', {
        prompt: prompt
      });

      return new Response(JSON.stringify({ report: response.response }), {
        headers: { "Content-Type": "application/json", ...corsHeaders }
      });
      
    } catch (error: any) {
      return new Response(JSON.stringify({ error: "Failed to generate report: " + error.message }), { 
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders }
      });
    }
  }
};